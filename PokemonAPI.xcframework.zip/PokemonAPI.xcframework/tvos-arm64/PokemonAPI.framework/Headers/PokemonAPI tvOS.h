//
//  PokemonAPI.h
//  PokemonAPI
//
//  Created by Christopher Jennewein on 10/16/21.
//

#import <Foundation/Foundation.h>

//! Project version number for PokemonAPI tvOS.
FOUNDATION_EXPORT double PokemonAPI_tvOSVersionNumber;

//! Project version string for PokemonAPI tvOS.
FOUNDATION_EXPORT const unsigned char PokemonAPI_tvOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PokemonAPI_tvOS/PublicHeader.h>


