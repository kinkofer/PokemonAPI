//
//  PokemonAPI.h
//  PokemonAPI
//
//  Created by Christopher Jennewein on 10/16/21.
//

#import <Foundation/Foundation.h>

//! Project version number for PokemonAPI watchOS.
FOUNDATION_EXPORT double PokemonAPI_watchOSVersionNumber;

//! Project version string for PokemonAPI watchOS.
FOUNDATION_EXPORT const unsigned char PokemonAPI_watchOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PokemonAPI_watchOS/PublicHeader.h>


