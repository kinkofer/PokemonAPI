//
//  PokemonAPI.h
//  PokemonAPI
//
//  Created by Christopher Jennewein on 10/16/21.
//

#import <Foundation/Foundation.h>

//! Project version number for PokemonAPI.
FOUNDATION_EXPORT double PokemonAPIVersionNumber;

//! Project version string for PokemonAPI.
FOUNDATION_EXPORT const unsigned char PokemonAPIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PokemonAPI/PublicHeader.h>


